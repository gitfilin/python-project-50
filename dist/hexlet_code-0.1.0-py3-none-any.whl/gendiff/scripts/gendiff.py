#!/usr/bin/env python3
from gendiff.cli import parse_arguments

def main():    
    args = parse_arguments()
    file1 = args.first_file
    file2 = args.second_file
    print(file1, file2)
    if args.formate:
        print("Форматирование включено")
    

if __name__ == '__main__':
    main()