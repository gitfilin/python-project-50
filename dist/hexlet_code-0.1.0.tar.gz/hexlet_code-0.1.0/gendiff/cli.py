import argparse


def parse_arguments():
    parser = argparse.ArgumentParser(
        description='Compares two configuration files and shows a difference.')
    # Позиционные аргументы
    parser.add_argument('first_file')
    parser.add_argument('second_file')
    # Опциональные аргументы с разными типами
    parser.add_argument('-f', '--FORMAT', action='store_true',
                        help='Выводить дополнительную информацию')
    args = parser.parse_args()
    if args.formate:
        pass

    return args


if __name__ == '__main__':
    parse_arguments()
